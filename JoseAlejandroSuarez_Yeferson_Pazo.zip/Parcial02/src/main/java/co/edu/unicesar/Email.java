package co.edu.unicesar;

public class Email extends EmailNoti {
    private String msg;


    public Email(String name) {
        super(name);
    }

}
