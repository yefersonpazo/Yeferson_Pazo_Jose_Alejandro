package co.edu.unicesar;

public class Push extends PushNoti {
    private String msgg;
    @Override
    public void send(Message message) {
    }
    public Push() {
    }

    public String getMsgg() {
        return msgg;
    }

    public void setMsgg(String msgg) {
        this.msgg = msgg;
    }



}
