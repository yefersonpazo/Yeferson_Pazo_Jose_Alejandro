package co.edu.unicesar;

public class SMS extends SMSNoti{
    private String sms;

    public SMS(String sms) {
        this.sms = sms;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

}
